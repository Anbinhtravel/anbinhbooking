export default function Home(){
return (
<main style={{padding:'40px'}}>
<h1>AnBinhBooking.com</h1>
<p>Nền tảng du lịch Next.js + Tailwind CSS</p>
</main>
)}