export default function Header(){
return <header>AnBinhBooking</header>
}